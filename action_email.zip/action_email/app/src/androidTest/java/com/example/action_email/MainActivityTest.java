package com.example.action_email;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}